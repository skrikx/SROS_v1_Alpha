"""Storage adapters package"""
from .filesystem_adapter import FilesystemAdapter

__all__ = ['FilesystemAdapter']
