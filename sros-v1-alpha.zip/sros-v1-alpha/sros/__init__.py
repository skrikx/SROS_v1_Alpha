"""
SROS v1: Sovereign Runtime Operating System
"""
__version__ = "1.0.0"
