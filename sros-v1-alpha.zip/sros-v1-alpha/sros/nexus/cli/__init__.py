"""CLI package"""
from .main import SROSCLI, main

__all__ = ['SROSCLI', 'main']
